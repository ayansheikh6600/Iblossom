
import CreateCourse_label from '@/components/course_label/CreateCourseLavel'
import React from 'react'

export default function Course_labelAdminCreatePage() {
  return (
    <div>
      <CreateCourse_label/>
    </div>
  )
}
