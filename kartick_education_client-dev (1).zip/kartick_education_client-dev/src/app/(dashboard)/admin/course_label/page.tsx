import Course_labelList from '@/components/course_label/CourseLavelList'
import React from 'react'

export default function AdminCourse_labelListPage() {
  return (
    <div><Course_labelList/></div>
  )
}
