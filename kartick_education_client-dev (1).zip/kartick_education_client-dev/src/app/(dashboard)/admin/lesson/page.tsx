import LessonDashList from '@/components/lesson/LessonDashList'
import React from 'react'

export default function LessonAdminListPage() {
  return (
    <div><LessonDashList/></div>
  )
}
