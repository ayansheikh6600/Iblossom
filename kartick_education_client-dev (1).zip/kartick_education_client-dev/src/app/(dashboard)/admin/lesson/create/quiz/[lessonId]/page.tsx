
import CreateQuizByLesson from '@/components/Quiz/create/CreateQuizByModule'
import React from 'react'


export default function CreateAdminQuizByLesson() {
  return (
    <div><CreateQuizByLesson /></div>
  )
}
