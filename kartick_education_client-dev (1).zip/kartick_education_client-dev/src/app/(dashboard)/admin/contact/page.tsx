import CategoryList from '@/components/category/CategoryList'
import ContactDashList from '@/components/contact/ContactDashList'
import React from 'react'

export default function AdminCategoryListPage() {
  return (
    <div><ContactDashList/></div>
  )
}
