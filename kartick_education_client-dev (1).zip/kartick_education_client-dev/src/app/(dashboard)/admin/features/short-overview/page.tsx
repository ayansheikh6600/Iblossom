import ShortOverview from '@/components/features/overview/ShortOverviewDashList'
import SkillsPlanDashList from '@/components/features/skills-plan/SkillsPlanDashList'
import React from 'react'

export default function SkillsPlanPage() {
  return (
    <div><ShortOverview /></div>
  )
}
