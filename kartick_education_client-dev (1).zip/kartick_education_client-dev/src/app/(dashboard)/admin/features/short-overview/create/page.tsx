
import CreateShortOverview from '@/components/features/overview/create/CreateShortOverview'
import React from 'react'

export default function CreateShortOverViewPage() {
    return (
        <div><CreateShortOverview /></div>
    )
}
