import React from "react";

export default function GlossaryList() {
  return <div>GlossaryList</div>;
}
