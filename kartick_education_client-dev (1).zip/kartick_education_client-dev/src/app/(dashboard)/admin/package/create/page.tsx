import CreatePackage from "@/components/package/create/CreatePackage";
import React from "react";

export default function CreatePackagePage() {
  return (
    <div>
      <CreatePackage />
    </div>
  );
}
