import QuizDashList from '@/components/Quiz/QuizDashList'
import React from 'react'

export default function QuizAdminListPage() {
  return (
    <div><QuizDashList/></div>
  )
}
