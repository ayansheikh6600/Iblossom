import CreateMilestoneByCourse from '@/components/milestone/create/CreateMilestoneByCourse'
import React from 'react'

export default function CreateAdminMilestoneByCoursePage() {
  return (
    <div><CreateMilestoneByCourse /></div>
  )
}
