import PurchaseCategoryTab from "@/components/Home/coureses/PurchaseCategoryTab";
import React from "react";

export default function PackageToCategoryAndCourse() {
  return (
    <div>
      <PurchaseCategoryTab />
    </div>
  );
}
