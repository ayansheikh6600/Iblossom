import SellerPurchased from '@/components/package/SellerPurchased'
import React from 'react'

export default function SellerPackage() {
  return (
    <div>
        <SellerPurchased/>,
    </div>
  )
}
