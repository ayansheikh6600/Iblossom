import OrderSummery from "@/components/dashboard/seller/OrderSummery";
import React from "react";

export default function SellerOrderSummeryPage() {
  return (
    <div className="flex justify-center items-center">
      {/* <OrderSummery /> */}
      <h1>Upcoming...</h1>
    </div>
  );
}
