import React from 'react'

export default function PackageToStudent() {
  return (
    <div>pagegjfgjfg</div>
  )
}
