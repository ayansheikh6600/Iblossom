import React from 'react'

export default function SellerCourse() {
  return (
    <div>SellerCourse</div>
  )
}
