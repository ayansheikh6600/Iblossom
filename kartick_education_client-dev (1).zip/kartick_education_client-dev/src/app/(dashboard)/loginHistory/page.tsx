import LoginHistory from "@/components/loginHistory/LoginHistory";
import React from "react";

export default function LoginHistoryPage() {
  return (
    <>
      <LoginHistory />
    </>
  );
}
