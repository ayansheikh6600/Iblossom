import ContactPage from "@/components/contact/ContactPage";
import React from "react";

export default function Contact() {
  return (
    <div>
      <ContactPage />
    </div>
  );
}
