import React from 'react'

export default function PaypalCancel() {
  return (
    <div>Cancel fully Paypal payment</div>
  )
}
