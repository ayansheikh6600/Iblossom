import Checkout from '@/components/checkout/Checkout'
import React from 'react'

export default function CheckoutPage() {
    return (
        <div><Checkout /></div>
    )
}
