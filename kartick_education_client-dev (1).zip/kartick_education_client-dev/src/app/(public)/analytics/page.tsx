'use client'
import AnalyticsMain from '@/components/analytics/AnalyticsMain'
import React from 'react'

export default function AnalyticsPage() {
    return (
        <div>

            <AnalyticsMain />

        </div>
    )
}
