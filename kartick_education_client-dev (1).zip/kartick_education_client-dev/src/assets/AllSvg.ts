import ModuleIcon from "./svg/moduleIcon";
import QuizIcon from "./svg/quizIcon";

export const AllSvg = {
  ModuleIcon,
  QuizIcon
};
