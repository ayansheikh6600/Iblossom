import React from "react";

const EventsByCategory = () => {
  return (
    <div
      style={{
        width: "75%",
        margin: "0 auto",
        padding: "60px 0",
      }}
    >
      <h1 className="text-base font-normal">Events by Category</h1>
    </div>
  );
};

export default EventsByCategory;
