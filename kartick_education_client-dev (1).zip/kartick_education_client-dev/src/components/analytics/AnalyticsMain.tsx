import React from 'react'
import AnalyticsTab from './AnalyticsTab'

export default function AnalyticsMain() {
  return (
    <div>
      <AnalyticsTab />
    </div>
  )
}
