import React from 'react'

export default function PackageDetails() {
  return (
    <div>PackageDetails</div>
  )
}
