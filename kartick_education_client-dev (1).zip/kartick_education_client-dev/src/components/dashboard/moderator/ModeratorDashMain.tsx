import React from 'react'

export default function ModeratorDashMain() {
  return (
    <div>ModeratorDashMain</div>
  )
}
