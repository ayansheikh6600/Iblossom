
* Any text editor value show then add this class name=> jodit-wysiwyg
